from django import forms 
from blog.models import Posts 
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User 


class PostForm(forms.ModelForm):

    Title = forms.CharField(widget=forms.TextInput(attrs={
        'placeholder':'Add post title', 'style': 'width:600px; font-size:20px;'
        })) 
    Content = forms.CharField(widget=forms.Textarea(attrs={
        'placeholder':'Add post content', 'style':'width:600px; font-size:15px'
        }))
    class Meta:
        model = Posts 
        fields = ['Title','Content','Author','Date'] 

class RegForm(UserCreationForm):

    FirstName = forms.CharField(widget=forms.TextInput(), required=True, label='First Name')
    LastName = forms.CharField(widget=forms.TextInput(), required=True, label='Last Name')
    email = forms.EmailField(widget=forms.TextInput(), label='Email') 
    class Meta:
        model = User 
        fields = ['FirstName', 'LastName','username','email','password1','password2'] 

class LogForm(UserCreationForm):
    
    class Meta:
        model = User
        fields = ['username', 'password'] 

