from django.urls import path, include 
from blog import views 
from blog.views import Home, Article, AddPost, UpdatePost, DeletePost 
urlpatterns = [
    #path('', views.home, name="Home")
    path('', Home.as_view(), name="Home"),
    path('article/<int:pk>', Article.as_view(), name='article-detail'),
    path('addpost/', AddPost.as_view(), name='add-post'),
    path('SignIn/', views.signin, name='add-user'),
    path('login/', views.Login, name='auth-user'),
    path('logout/', views.Logout, name='logout-user'),
    path('article/update/<int:pk>', UpdatePost.as_view(), name='update-post'),
    path('article/delete/<int:pk>', DeletePost.as_view(), name='delete-post')   
]