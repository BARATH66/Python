from django.db import models
from django.contrib.auth.models import User
from django.urls import reverse
from django.utils import timezone
from django import forms 

# Create your models here.
class Posts(models.Model):
    Title = models.CharField(max_length=200)
    Content = models.TextField()
    Author = models.ForeignKey(User, on_delete=models.CASCADE) 
    Date = models.DateField(default=timezone.now().strftime('%Y-%m-%d'))

    def __str__(self):
        return self.Title 

    def get_absolute_url(self):
        return reverse('article-detail', kwargs={'pk':self.pk}) 