from django.shortcuts import render, redirect
from django.views.generic import ListView, DetailView, CreateView
from django.views.generic.edit import  UpdateView, DeleteView
from blog.models import Posts
from blog.forms import PostForm, RegForm
from django.contrib import messages
from django.contrib.auth import login, logout 
from django.contrib.auth.forms import AuthenticationForm 
from django.urls import reverse_lazy

# Create your views here.

class Home(ListView):
    model = Posts 
    template_name = 'home.html'     

class Article(DetailView):
    model = Posts
    template_name = 'article.html'

class AddPost(CreateView):
    model = Posts
    form_class = PostForm
    template_name = 'addpost.html' 
    

def signin(re):
    if re.method == "POST":
        form = RegForm(re.POST)
        if form.is_valid():
            form.save() 
            messages.success(re, 'Registration successful..')
            return redirect('Home') 

    else:
        form = RegForm()
    return render(re, 'signin.html',{'form':form}) 

def Login(re):
    if re.method == 'POST':
        form = AuthenticationForm(re, data=re.POST) 
        if form.is_valid():
            user = form.get_user()
            login(re, user)
            messages.info(re, f'{user} has logged in..')
            return redirect("Home") 
            
        else:
            messages.error(re, 'Invalid Username or PassWord') 
    else:
        form = AuthenticationForm()
    return render (re, 'login.html', {'login_form':form})

def Logout(re):
    logout(re)
    messages.info(re, 'You have sucessfully logged out...')
    return redirect('Home') 

class UpdatePost(UpdateView):
    model = Posts
    template_name = 'update.html'
    fields = ['Title', 'Content','Date'] 

class DeletePost(DeleteView):
    model = Posts 
    template_name = 'delete.html'
    fields = '__all__'
    
    def get_success_url(self): 
        return reverse_lazy('Home')